classdef HMOFA < ALGORITHM
% <multi/many> <real> <large/none> <expensive/none>
% A Hybrid Multi-Objective Firefly Algorithm for Big Data Optimization
% beta0  --- 1 ---       Attraction Coefficient Base Value
% alpha  --- 0.5---     Mutation Coefficient
% CR --- 0.7 --- Mutation Coefficient Damping Ratio


%----------------------------           --- Reference --------------------------------
% Hui Wang, Wenjun Wang, Laizhong Cui, Hui Sun, Jia Zhao, Yun Wang, Yu Xue,
% A hybrid multi-objective firefly algorithm for big data optimization,
% Applied Soft Computing,Volume 69,2018,Pages 806-815,ISSN 1568-4946,
% https://doi.org/10.1016/j.asoc.2017.06.029.
%------------------------------- Copyright --------------------------------
% Copyright (c) 2021 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng,  Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    methods
        function main(Algorithm,Problem)
            %% Generate random population
            [beta0,alpha,CR]= Algorithm.ParameterSet(1,0.5,0.7);
            Population = Problem.Initialization();
            Problem = PROBLEM.Current();
            delta   = 0.5*(Problem.upper-Problem.lower); % Uniform Mutation Range
            gamma = 1/(Problem.D)^2;
            if isscalar(Problem.lower) && isscalar(Problem.upper)
                dmax = (Problem.upper-Problem.lower)*sqrt(D);
            else
                dmax = norm(Problem.upper-Problem.lower);
            end
                      
            while Algorithm.NotTerminated(Population)

                % learning
                Offspring  = Operator(Population,gamma,beta0,alpha,delta,dmax,CR);
             
                Offspring  = OperatorGA(Offspring);
               
                Population =  EnvironmentalSelection([Population,Offspring],Problem.N);
           
                Problem = PROBLEM.Current();
                alpha = alpha * (1 - Problem.FE/Problem.maxFE); %alpha_damp;
            end
        end
    end
end