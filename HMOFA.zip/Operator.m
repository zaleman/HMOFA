function Offspring = Operator(Population,gamma,beta0,alpha,delta,dmax,CR)
% A Hybrid Multi-Objective Firefly Algorithm for Big Data Optimization
%------------------------------- Copyright --------------------------------
% Copyright (c) 2021 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------
    %% Parameter setting
%     [FrontNo,MaxFNo]     = NDSort(Population.objs,inf);   
    Problem = PROBLEM.Current();
    Lower = Problem.lower;
    Upper = Problem.upper;
    PopObj = Population.objs;
    PopDec = Population.decs;
    [N,D]   = size( PopDec); 
    % learning
    for i = 1:N
        for j = 1:N
            if i~= j
                % j dominate i
                if all(PopObj(j,:) <= PopObj(i,:)) ...
                        && any(PopObj(j,:) < PopObj(i,:))
                    % updete beta
                    if rand < 0.5
                        beta0 = rand;
                    end
                    r      = norm(PopDec(i,:)-PopDec(i,:))/dmax;
                    beta   = beta0 * exp(-gamma*r^2);
                    e      = delta .* unifrnd(-1,+1,[1,D]);
                    NewPopDec = PopDec(i,:) ...
                        + beta .* (PopDec(j,:) - PopDec(i,:))...
                        + alpha .* e;
                    % 限界
                    NewPopDec = min(max(NewPopDec,Lower),Upper);
                    NewPopObj = Problem.CalObj(NewPopDec);
                    
                    % DE crossover
                    for d = 1:D
                        if rand < CR || d == randperm(D,1)
                            BestPopDec(1,d) = NewPopDec(1,d);
                        else
                            BestPopDec(1,d) = PopDec(i,d);
                        end
                    end
                    BestPopObj = Problem.CalObj(BestPopDec);
                    % 比较支配关系
                    if all(BestPopObj <= NewPopObj) ...
                                && any(BestPopObj  < NewPopObj)
                        PopDec(i,:) = BestPopDec;
                        PopObj(i,:) = BestPopObj;
                    else 
                        PopDec(i,:) = NewPopDec;
                        PopObj(i,:) = NewPopObj;
                    end
                end
            end
        end
    end
  
	Offspring = SOLUTION(PopDec);
end